mod app;
mod event;
mod files;
mod input;
mod terminal;
mod theme;
mod ui;
mod view;

use std::io;
use std::process::ExitCode;

fn main() -> ExitCode {
    terminal::install_panic_hook();

    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("nexus-tui: {error}");
            ExitCode::FAILURE
        }
    }
}

fn run() -> io::Result<()> {
    let mut session = terminal::init()?;
    let (width, height) = session.size()?;
    let mut app = app::App::with_environment(width, height);

    let run_result = event_loop(&mut session, &mut app);
    let restore_result = session.shutdown();

    match (run_result, restore_result) {
        (Ok(()), Ok(())) => Ok(()),
        (Err(error), Ok(())) | (Ok(()), Err(error)) => Err(error),
        (Err(run_error), Err(restore_error)) => Err(io::Error::new(
            run_error.kind(),
            format!("{run_error}; falha adicional ao restaurar o terminal: {restore_error}"),
        )),
    }
}

fn event_loop(session: &mut terminal::TerminalSession, app: &mut app::App) -> io::Result<()> {
    while app.is_running() {
        if app.needs_redraw() {
            session
                .terminal_mut()
                .draw(|frame| ui::render(frame, app))?;
            app.mark_rendered();
        }

        if let Some(event) = event::read(event::POLL_INTERVAL)? {
            app.update(event);
        } else {
            app.on_idle();
        }
    }

    app.on_idle();

    Ok(())
}
