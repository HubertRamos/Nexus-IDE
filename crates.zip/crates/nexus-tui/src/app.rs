use std::fmt;
use std::path::{Path, PathBuf};

use nexus_core::buffer::Buffer;
use nexus_core::buffer::Transaction;
use nexus_core::buffer::edit::BufferError;
use nexus_core::buffer::edit::{AppliedEdit, Edit, TextRange};
use nexus_core::buffer::position::CharOffset;
use nexus_syntax::{LanguageId, SyntaxState};

use crate::event::Event;
use crate::files::{self, FileError};
use crate::input::{Action, ConfirmAction};
use crate::theme::{ColorMode, ThemeState};
use crate::view::{Motion, View, char_width, editor_content_size};

/// Modo de interação da interface.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Mode {
    Editor,
    Prompt(PromptKind),
    Help,
    Confirm,
}

/// Motivo da confirmação aberta.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConfirmKind {
    Quit,
    Open,
}

/// Escolha oferecida na confirmação de alterações não salvas.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConfirmChoice {
    Save,
    Discard,
    Cancel,
}

impl ConfirmChoice {
    fn next(self, save_available: bool) -> Self {
        match (self, save_available) {
            (ConfirmChoice::Save, _) => ConfirmChoice::Discard,
            (ConfirmChoice::Discard, _) => ConfirmChoice::Cancel,
            (ConfirmChoice::Cancel, true) => ConfirmChoice::Save,
            (ConfirmChoice::Cancel, false) => ConfirmChoice::Discard,
        }
    }

    fn previous(self, save_available: bool) -> Self {
        match (self, save_available) {
            (ConfirmChoice::Save, _) => ConfirmChoice::Cancel,
            (ConfirmChoice::Discard, true) => ConfirmChoice::Save,
            (ConfirmChoice::Discard, false) => ConfirmChoice::Cancel,
            (ConfirmChoice::Cancel, _) => ConfirmChoice::Discard,
        }
    }
}

/// Ação que será concluída depois de salvar ou descartar as alterações.
#[derive(Debug, Clone)]
enum PendingAction {
    Quit,
    Open(PathBuf),
}

/// Diálogo de confirmação de alterações não salvas.
#[derive(Debug, Clone)]
pub struct ConfirmDialog {
    pending: PendingAction,
    selected: ConfirmChoice,
    save_available: bool,
    error: Option<String>,
}

impl ConfirmDialog {
    pub fn kind(&self) -> ConfirmKind {
        match &self.pending {
            PendingAction::Quit => ConfirmKind::Quit,
            PendingAction::Open(_) => ConfirmKind::Open,
        }
    }

    pub fn selected(&self) -> ConfirmChoice {
        self.selected
    }

    pub fn save_available(&self) -> bool {
        self.save_available
    }

    pub fn error(&self) -> Option<&str> {
        self.error.as_deref()
    }

    pub fn target(&self) -> Option<&Path> {
        match &self.pending {
            PendingAction::Open(path) => Some(path),
            PendingAction::Quit => None,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PromptKind {
    Open,
    SaveAs,
}

impl PromptKind {
    pub fn title(self) -> &'static str {
        match self {
            PromptKind::Open => "Abrir arquivo",
            PromptKind::SaveAs => "Salvar como",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MessageKind {
    Info,
    Error,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StatusMessage {
    pub kind: MessageKind,
    pub text: String,
}

/// Prompt de caminho de arquivo.
#[derive(Debug, Clone)]
pub struct Prompt {
    kind: PromptKind,
    input: String,
    cursor: usize,
}

impl Prompt {
    fn new(kind: PromptKind, input: String) -> Self {
        let cursor = input.chars().count();
        Self {
            kind,
            input,
            cursor,
        }
    }

    pub fn kind(&self) -> PromptKind {
        self.kind
    }

    pub fn input(&self) -> &str {
        &self.input
    }

    pub fn cursor(&self) -> usize {
        self.cursor
    }

    /// Índice do primeiro caractere visível para uma largura interna.
    ///
    /// O conteúdo completo permanece em `input`; este método calcula apenas a
    /// janela horizontal usada na renderização, mantendo o cursor visível.
    pub fn visible_start(&self, width: usize) -> usize {
        prompt_visible_start(&self.input, self.cursor, width)
    }

    fn insert_char(&mut self, character: char) {
        let byte_index = self.byte_index(self.cursor);
        self.input.insert(byte_index, character);
        self.cursor += 1;
    }

    fn backspace(&mut self) {
        if self.cursor == 0 {
            return;
        }

        let start = self.byte_index(self.cursor - 1);
        let end = self.byte_index(self.cursor);
        self.input.replace_range(start..end, "");
        self.cursor -= 1;
    }

    fn delete(&mut self) {
        if self.cursor >= self.input.chars().count() {
            return;
        }

        let start = self.byte_index(self.cursor);
        let end = self.byte_index(self.cursor + 1);
        self.input.replace_range(start..end, "");
    }

    fn move_left(&mut self) {
        self.cursor = self.cursor.saturating_sub(1);
    }

    fn move_right(&mut self) {
        self.cursor = (self.cursor + 1).min(self.input.chars().count());
    }

    fn move_home(&mut self) {
        self.cursor = 0;
    }

    fn move_end(&mut self) {
        self.cursor = self.input.chars().count();
    }

    fn byte_index(&self, char_index: usize) -> usize {
        self.input
            .char_indices()
            .nth(char_index)
            .map(|(index, _)| index)
            .unwrap_or(self.input.len())
    }
}

#[derive(Debug)]
pub enum DocumentError {
    Buffer(BufferError),
    File(FileError),
}

impl fmt::Display for DocumentError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            DocumentError::Buffer(error) => write!(formatter, "{error}"),
            DocumentError::File(error) => write!(formatter, "{error}"),
        }
    }
}

impl std::error::Error for DocumentError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            DocumentError::Buffer(error) => Some(error),
            DocumentError::File(error) => Some(error),
        }
    }
}

impl From<BufferError> for DocumentError {
    fn from(error: BufferError) -> Self {
        DocumentError::Buffer(error)
    }
}

impl From<FileError> for DocumentError {
    fn from(error: FileError) -> Self {
        DocumentError::File(error)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum EditKind {
    Insert,
    DeleteBackward,
    DeleteForward,
}

pub struct App {
    buffer: Buffer,
    view: View,
    path: Option<PathBuf>,
    document_name: String,
    line_ending: String,
    running: bool,
    needs_redraw: bool,
    width: u16,
    height: u16,
    mode: Mode,
    prompt: Option<Prompt>,
    confirm: Option<ConfirmDialog>,
    pending_after_save: Option<PendingAction>,
    status: Option<StatusMessage>,
    session: Option<EditKind>,
    theme: ThemeState,
    syntax: Option<SyntaxState>,
}

impl App {
    /// Cria a aplicação com temas internos para testes determinísticos.
    #[cfg(test)]
    pub fn new(width: u16, height: u16) -> Self {
        Self::with_text(width, height, "")
    }

    /// Cria a aplicação carregando temas externos e a seleção persistida.
    pub fn with_environment(width: u16, height: u16) -> Self {
        let theme = ThemeState::from_environment(ColorMode::detect());
        let mut app = Self::with_theme(width, height, "", theme);

        if let Some(summary) = app.theme.warning_summary() {
            app.set_error(summary);
        }

        app
    }

    /// Cria a aplicação com um documento inicial e temas internos.
    ///
    /// Usado pelos testes para manter execuções determinísticas; o conteúdo
    /// sempre pertence ao `Buffer` do Core.
    #[cfg(test)]
    pub fn with_text(width: u16, height: u16, text: &str) -> Self {
        Self::with_theme(
            width,
            height,
            text,
            ThemeState::builtin(ColorMode::TrueColor),
        )
    }

    /// Cria a aplicação com um documento já associado a um caminho.
    ///
    /// O texto é recebido já lido; a análise sintática é criada conforme a
    /// extensão do caminho.
    #[cfg(test)]
    pub fn with_document(width: u16, height: u16, path: &Path, text: &str) -> Self {
        let mut app = Self::with_text(width, height, text);
        app.path = Some(path.to_path_buf());
        app.document_name = document_name(path);
        app.syntax = LanguageId::from_path(path).map(|language| SyntaxState::new(language, text));
        app
    }

    fn with_theme(width: u16, height: u16, text: &str, theme: ThemeState) -> Self {
        let buffer = Buffer::from_text(text);
        let line_count = buffer.len_lines().unwrap_or(1);
        let (cols, rows) = editor_content_size(width, height, line_count);

        let mut view = View::new();
        view.set_content_size(cols, rows);

        Self {
            buffer,
            view,
            path: None,
            document_name: "sem título".to_owned(),
            line_ending: detect_line_ending(text).to_owned(),
            running: true,
            needs_redraw: true,
            width,
            height,
            mode: Mode::Editor,
            prompt: None,
            confirm: None,
            pending_after_save: None,
            status: None,
            session: None,
            theme,
            syntax: None,
        }
    }

    pub fn buffer(&self) -> &Buffer {
        &self.buffer
    }

    pub fn view(&self) -> &View {
        &self.view
    }

    pub fn path(&self) -> Option<&Path> {
        self.path.as_deref()
    }

    pub fn document_name(&self) -> &str {
        &self.document_name
    }

    pub fn terminal_size(&self) -> (u16, u16) {
        (self.width, self.height)
    }

    pub fn is_running(&self) -> bool {
        self.running
    }

    pub fn needs_redraw(&self) -> bool {
        self.needs_redraw
    }

    pub fn mode(&self) -> Mode {
        self.mode
    }

    pub fn prompt(&self) -> Option<&Prompt> {
        self.prompt.as_ref()
    }

    pub fn confirm(&self) -> Option<&ConfirmDialog> {
        self.confirm.as_ref()
    }

    pub fn status_message(&self) -> Option<&StatusMessage> {
        self.status.as_ref()
    }

    pub fn theme(&self) -> &ThemeState {
        &self.theme
    }

    pub fn syntax(&self) -> Option<&SyntaxState> {
        self.syntax.as_ref()
    }

    /// Nome da linguagem reconhecida, ou `Texto` quando não há highlighting.
    pub fn language_name(&self) -> &'static str {
        self.syntax
            .as_ref()
            .map(|syntax| syntax.language().display_name())
            .unwrap_or("Texto")
    }

    pub fn mark_rendered(&mut self) {
        self.needs_redraw = false;
    }

    /// Finaliza uma sessão de digitação quando o usuário fica inativo.
    ///
    /// O laço de eventos chama este método quando `poll` expira. Assim, uma
    /// pausa fecha a sessão sem exigir um timer próprio na aplicação.
    pub fn on_idle(&mut self) {
        if self.session.is_some() || self.buffer.has_active_transaction() {
            self.commit_session();
        }
    }

    /// Aplica um evento já recebido ao estado da aplicação.
    pub fn update(&mut self, event: Event) {
        match event {
            Event::Key(key) => {
                if self.mode == Mode::Confirm {
                    if let Some(action) = crate::input::confirm_action(key) {
                        self.apply_confirm_action(action);
                    }
                    return;
                }

                let action = match self.mode {
                    Mode::Prompt(_) => crate::input::prompt_action(key),
                    Mode::Editor | Mode::Help => crate::input::action(key),
                    Mode::Confirm => None,
                };

                if let Some(action) = action {
                    self.apply_action(action);
                }
            }
            Event::Resize { width, height } => {
                self.width = width;
                self.height = height;
                self.sync_viewport();
                if self.buffer.is_consistent() {
                    self.ensure_visible();
                }
                self.needs_redraw = true;
            }
        }
    }

    fn apply_action(&mut self, action: Action) {
        if action == Action::Quit {
            self.request_quit();
            return;
        }

        match self.mode {
            Mode::Prompt(_) => self.apply_prompt_action(action),
            Mode::Help => self.apply_help_action(action),
            Mode::Editor => self.apply_editor_action(action),
            Mode::Confirm => {}
        }
    }

    fn apply_help_action(&mut self, action: Action) {
        match action {
            Action::ToggleHelp | Action::CancelSelection => {
                self.mode = Mode::Editor;
                self.needs_redraw = true;
            }
            _ => {}
        }
    }

    fn apply_prompt_action(&mut self, action: Action) {
        match action {
            Action::PromptChar(character) => {
                if let Some(prompt) = self.prompt.as_mut() {
                    prompt.insert_char(character);
                    self.needs_redraw = true;
                }
            }
            Action::PromptBackspace => {
                if let Some(prompt) = self.prompt.as_mut() {
                    prompt.backspace();
                    self.needs_redraw = true;
                }
            }
            Action::PromptDelete => {
                if let Some(prompt) = self.prompt.as_mut() {
                    prompt.delete();
                    self.needs_redraw = true;
                }
            }
            Action::PromptLeft => {
                if let Some(prompt) = self.prompt.as_mut() {
                    prompt.move_left();
                    self.needs_redraw = true;
                }
            }
            Action::PromptRight => {
                if let Some(prompt) = self.prompt.as_mut() {
                    prompt.move_right();
                    self.needs_redraw = true;
                }
            }
            Action::PromptHome => {
                if let Some(prompt) = self.prompt.as_mut() {
                    prompt.move_home();
                    self.needs_redraw = true;
                }
            }
            Action::PromptEnd => {
                if let Some(prompt) = self.prompt.as_mut() {
                    prompt.move_end();
                    self.needs_redraw = true;
                }
            }
            Action::PromptConfirm => self.confirm_prompt(),
            Action::PromptCancel => self.cancel_prompt(),
            _ => {}
        }
    }

    fn apply_editor_action(&mut self, action: Action) {
        match action {
            Action::MoveLeft { select } => self.move_cursor(Motion::Left, select),
            Action::MoveRight { select } => self.move_cursor(Motion::Right, select),
            Action::MoveUp { select } => self.move_cursor(Motion::Up, select),
            Action::MoveDown { select } => self.move_cursor(Motion::Down, select),
            Action::MoveLineStart { select } => self.move_cursor(Motion::LineStart, select),
            Action::MoveLineEnd { select } => self.move_cursor(Motion::LineEnd, select),
            Action::MoveDocStart { select } => self.move_cursor(Motion::DocStart, select),
            Action::MoveDocEnd { select } => self.move_cursor(Motion::DocEnd, select),
            Action::MovePageUp { select } => self.move_cursor(Motion::PageUp, select),
            Action::MovePageDown { select } => self.move_cursor(Motion::PageDown, select),
            Action::InsertChar(character) => self.insert_char(character),
            Action::InsertTab => self.insert_text("\t", EditKind::Insert),
            Action::InsertNewline => {
                let newline = self.line_ending.clone();
                self.insert_text(&newline, EditKind::Insert);
            }
            Action::Backspace => self.backspace(),
            Action::DeleteForward => self.delete_forward(),
            Action::Undo => self.undo(),
            Action::Redo => self.redo(),
            Action::SelectAll => self.select_all(),
            Action::CancelSelection => {
                self.commit_session();
                self.view.clear_selection();
                self.needs_redraw = true;
            }
            Action::OpenPrompt => {
                if self.confirm.is_some() {
                    return;
                }
                self.commit_session();
                self.open_prompt(PromptKind::Open);
            }
            Action::Save => {
                if self.buffer.is_consistent() {
                    self.save();
                } else {
                    self.set_error("documento em recuperação pendente; salvar indisponível");
                }
            }
            Action::SaveAsPrompt => {
                self.commit_session();
                if self.buffer.is_consistent() {
                    self.open_prompt(PromptKind::SaveAs);
                } else {
                    self.set_error("documento em recuperação pendente; salvar indisponível");
                }
            }
            Action::ToggleHelp => {
                self.mode = Mode::Help;
                self.needs_redraw = true;
            }
            Action::Quit
            | Action::PromptChar(_)
            | Action::PromptBackspace
            | Action::PromptDelete
            | Action::PromptLeft
            | Action::PromptRight
            | Action::PromptHome
            | Action::PromptEnd
            | Action::PromptConfirm
            | Action::PromptCancel => {}
        }
    }

    fn move_cursor(&mut self, motion: Motion, select: bool) {
        self.commit_session();

        match self.view.move_cursor(&self.buffer, motion, select) {
            Ok(_) => self.needs_redraw = true,
            Err(error) => {
                self.report_buffer_error("não foi possível mover o cursor", &error);
            }
        }
    }

    fn insert_char(&mut self, character: char) {
        self.insert_text(&character.to_string(), EditKind::Insert);
    }

    fn insert_text(&mut self, text: &str, kind: EditKind) {
        if !self.buffer.is_consistent() {
            self.report_recovery();
            return;
        }

        if let Some(range) = self.view.selection_range() {
            self.commit_session();
            let inserted_len = text.chars().count();

            match self
                .buffer
                .apply_transaction(vec![Edit::new(range, text.to_owned())])
            {
                Ok(transaction) => {
                    if let Some(transaction) = &transaction {
                        self.apply_syntax_transaction(transaction);
                    }
                    self.view.clear_selection();
                    self.set_cursor_after_edit(CharOffset(range.start.0 + inserted_len));
                }
                Err(error) => {
                    self.report_buffer_error("não foi possível substituir a seleção", &error);
                }
            }

            return;
        }

        if !self.ensure_session(kind) {
            return;
        }

        let cursor = self.view.cursor();

        match self.buffer.insert(cursor, text) {
            Ok(Some(applied)) => {
                self.apply_syntax_edit(&applied);
                self.set_cursor_after_edit(CharOffset(cursor.0 + text.chars().count()));
            }
            Ok(None) => {}
            Err(error) => {
                self.report_buffer_error("não foi possível inserir texto", &error);
                self.commit_session();
            }
        }
    }

    fn backspace(&mut self) {
        if !self.buffer.is_consistent() {
            self.report_recovery();
            return;
        }

        if self.view.has_selection() {
            self.delete_selection();
            return;
        }

        let cursor = self.view.cursor();
        if cursor.0 == 0 {
            return;
        }

        let line = match self.view.cursor_line(&self.buffer) {
            Ok(line) => line,
            Err(error) => {
                self.report_buffer_error("não foi possível localizar a linha do cursor", &error);
                return;
            }
        };

        let line_start = match self.buffer.line_start(line) {
            Ok(start) => start,
            Err(error) => {
                self.report_buffer_error("não foi possível localizar o início da linha", &error);
                return;
            }
        };

        let range = if cursor > line_start {
            TextRange::new(CharOffset(cursor.0 - 1), cursor)
        } else {
            match self.buffer.line_end(line - 1) {
                Ok(previous_end) => TextRange::new(previous_end, cursor),
                Err(error) => {
                    self.report_buffer_error("não foi possível remover a quebra de linha", &error);
                    return;
                }
            }
        };

        if !self.ensure_session(EditKind::DeleteBackward) {
            return;
        }

        match self.buffer.delete(range) {
            Ok(Some(applied)) => {
                self.apply_syntax_edit(&applied);
                self.set_cursor_after_edit(range.start);
            }
            Ok(None) => {}
            Err(error) => {
                self.report_buffer_error("não foi possível apagar", &error);
                self.commit_session();
            }
        }
    }

    fn delete_forward(&mut self) {
        if !self.buffer.is_consistent() {
            self.report_recovery();
            return;
        }

        if self.view.has_selection() {
            self.delete_selection();
            return;
        }

        let cursor = self.view.cursor();
        let line = match self.view.cursor_line(&self.buffer) {
            Ok(line) => line,
            Err(error) => {
                self.report_buffer_error("não foi possível localizar a linha do cursor", &error);
                return;
            }
        };

        let line_end = match self.buffer.line_end(line) {
            Ok(end) => end,
            Err(error) => {
                self.report_buffer_error("não foi possível localizar o fim da linha", &error);
                return;
            }
        };

        let range = if cursor < line_end {
            TextRange::new(cursor, CharOffset(cursor.0 + 1))
        } else {
            let lines = match self.buffer.line_count() {
                Ok(lines) => lines,
                Err(error) => {
                    self.report_buffer_error("não foi possível contar as linhas", &error);
                    return;
                }
            };

            if line + 1 >= lines {
                return;
            }

            match self.buffer.line_start(line + 1) {
                Ok(next_start) => TextRange::new(cursor, next_start),
                Err(error) => {
                    self.report_buffer_error("não foi possível remover a quebra de linha", &error);
                    return;
                }
            }
        };

        if !self.ensure_session(EditKind::DeleteForward) {
            return;
        }

        match self.buffer.delete(range) {
            Ok(Some(applied)) => {
                self.apply_syntax_edit(&applied);
                self.set_cursor_after_edit(cursor);
            }
            Ok(None) => {}
            Err(error) => {
                self.report_buffer_error("não foi possível apagar", &error);
                self.commit_session();
            }
        }
    }

    fn delete_selection(&mut self) {
        let Some(range) = self.view.selection_range() else {
            return;
        };

        self.commit_session();

        match self
            .buffer
            .apply_transaction(vec![Edit::new(range, String::new())])
        {
            Ok(transaction) => {
                if let Some(transaction) = &transaction {
                    self.apply_syntax_transaction(transaction);
                }
                self.view.clear_selection();
                self.set_cursor_after_edit(range.start);
            }
            Err(error) => {
                self.report_buffer_error("não foi possível excluir a seleção", &error);
            }
        }
    }

    fn select_all(&mut self) {
        self.commit_session();

        match self.view.select_all(&self.buffer) {
            Ok(()) => self.needs_redraw = true,
            Err(error) => {
                self.report_buffer_error("não foi possível selecionar o documento", &error);
            }
        }
    }

    fn undo(&mut self) {
        self.commit_session();

        match self.buffer.undo() {
            Ok(true) => {
                self.after_history_change();
                self.set_info("desfeito");
            }
            Ok(false) => self.set_info("nada para desfazer"),
            Err(error) => self.report_buffer_error("não foi possível desfazer", &error),
        }
    }

    fn redo(&mut self) {
        self.commit_session();

        match self.buffer.redo() {
            Ok(true) => {
                self.after_history_change();
                self.set_info("refeito");
            }
            Ok(false) => self.set_info("nada para refazer"),
            Err(error) => self.report_buffer_error("não foi possível refazer", &error),
        }
    }

    fn after_history_change(&mut self) {
        self.view.clear_selection();
        self.sync_viewport();
        let cursor = self.view.cursor();

        if let Err(error) = self.view.set_cursor(&self.buffer, cursor) {
            self.report_buffer_error("não foi possível ajustar o cursor após o histórico", &error);
        }

        self.resync_syntax();
        self.needs_redraw = true;
    }

    fn apply_syntax_edit(&mut self, edit: &AppliedEdit) {
        if self.syntax.is_none() {
            return;
        }

        let result = self
            .syntax
            .as_mut()
            .map(|syntax| syntax.apply_edit(edit.range, &edit.deleted_text, &edit.inserted_text));

        if let Some(Err(error)) = result {
            self.disable_syntax(error);
        }
    }

    fn apply_syntax_transaction(&mut self, transaction: &Transaction) {
        for edit in transaction.edits() {
            if self.syntax.is_none() {
                return;
            }

            let result = self.syntax.as_mut().map(|syntax| {
                syntax.apply_edit(edit.range, &edit.deleted_text, &edit.inserted_text)
            });

            if let Some(Err(error)) = result {
                self.disable_syntax(error);
                return;
            }
        }
    }

    /// Recalcula a menor edição entre o texto atual e o estado sintático.
    ///
    /// Usado em Undo/Redo, quando o Core não expõe as edições aplicadas.
    fn resync_syntax(&mut self) {
        if self.syntax.is_none() {
            return;
        }

        let text = match self.buffer.text() {
            Ok(text) => text,
            Err(_) => {
                self.syntax = None;
                return;
            }
        };

        let result = self.syntax.as_mut().map(|syntax| syntax.resync(&text));

        if let Some(Err(error)) = result {
            self.disable_syntax(error);
        }
    }

    fn disable_syntax(&mut self, error: nexus_syntax::SyntaxError) {
        self.syntax = None;
        self.set_error(format!("highlighting desativado: {error}"));
    }

    /// Ajusta a linguagem depois de Salvar Como.
    ///
    /// Se a extensão não mudou, a árvore existente é preservada. Caso
    /// contrário, o estado é recriado a partir do texto já salvo.
    fn set_syntax_for_path(&mut self, path: &Path, text: &str) {
        let language = LanguageId::from_path(path);

        match (&self.syntax, language) {
            (Some(state), Some(language)) if state.language() == language => {}
            (None, None) => {}
            _ => {
                self.syntax = language.map(|language| SyntaxState::new(language, text));
            }
        }
    }

    fn ensure_session(&mut self, kind: EditKind) -> bool {
        if self.session == Some(kind) && self.buffer.has_active_transaction() {
            return true;
        }

        self.commit_session();

        if !self.buffer.is_consistent() {
            self.report_recovery();
            return false;
        }

        match self.buffer.begin_transaction() {
            Ok(()) => {
                self.session = Some(kind);
                true
            }
            Err(error) => {
                self.report_buffer_error("não foi possível iniciar a sessão de edição", &error);
                false
            }
        }
    }

    fn commit_session(&mut self) {
        let had_session = self.session.is_some() || self.buffer.has_active_transaction();
        self.session = None;

        if !self.buffer.has_active_transaction() {
            return;
        }

        match self.buffer.commit_transaction() {
            Ok(_) => {
                if had_session {
                    self.needs_redraw = true;
                }
            }
            Err(error) => {
                self.report_buffer_error("não foi possível concluir a sessão de edição", &error);
            }
        }
    }

    fn cancel_session(&mut self) {
        self.session = None;

        if !self.buffer.has_active_transaction() {
            return;
        }

        match self.buffer.cancel_transaction() {
            Ok(()) => self.resync_syntax(),
            Err(error) => {
                self.report_buffer_error("não foi possível cancelar a sessão de edição", &error);
            }
        }
    }

    fn set_cursor_after_edit(&mut self, offset: CharOffset) {
        self.view.clear_selection();
        self.sync_viewport();

        if let Err(error) = self.view.set_cursor(&self.buffer, offset) {
            self.report_buffer_error("não foi possível atualizar o cursor", &error);
        }

        self.needs_redraw = true;
    }

    fn sync_viewport(&mut self) {
        let line_count = if self.buffer.is_consistent() {
            self.buffer.line_count().unwrap_or(1)
        } else {
            1
        };

        let (cols, rows) = editor_content_size(self.width, self.height, line_count);
        self.view.set_content_size(cols, rows);
    }

    fn ensure_visible(&mut self) {
        if let Err(error) = self.view.ensure_visible(&self.buffer) {
            self.report_buffer_error("não foi possível ajustar o viewport", &error);
        }
    }

    fn open_prompt(&mut self, kind: PromptKind) {
        let initial = match kind {
            PromptKind::Open => String::new(),
            PromptKind::SaveAs => self
                .path()
                .map(|path| path.to_string_lossy().into_owned())
                .unwrap_or_default(),
        };

        self.prompt = Some(Prompt::new(kind, initial));
        self.mode = Mode::Prompt(kind);
        self.needs_redraw = true;
    }

    fn confirm_prompt(&mut self) {
        let Some(prompt) = self.prompt.take() else {
            self.mode = Mode::Editor;
            return;
        };

        match prompt.kind {
            PromptKind::Open => {
                if prompt.input().is_empty() {
                    self.prompt = Some(prompt);
                    self.set_error(FileError::EmptyPath.to_string());
                    return;
                }

                let path = PathBuf::from(prompt.input());

                if self.buffer.is_modified() || !self.buffer.is_consistent() {
                    self.open_confirm(PendingAction::Open(path));
                    return;
                }

                match self.open_document(&path) {
                    Ok(()) => self.mode = Mode::Editor,
                    Err(error) => {
                        self.prompt = Some(prompt);
                        self.set_error(error.to_string());
                    }
                }
            }
            PromptKind::SaveAs => match self.save_document_to(Path::new(prompt.input())) {
                Ok(()) => {
                    self.mode = Mode::Editor;
                    if let Some(pending) = self.pending_after_save.take() {
                        self.complete_pending(pending);
                    }
                }
                Err(error) => {
                    self.prompt = Some(prompt);
                    self.set_error(error.to_string());
                }
            },
        }
    }

    fn cancel_prompt(&mut self) {
        self.prompt = None;
        self.mode = Mode::Editor;
        self.needs_redraw = true;

        match self.pending_after_save.take() {
            Some(PendingAction::Quit) => self.set_info("saída cancelada"),
            Some(PendingAction::Open(_)) => self.set_info("abertura cancelada"),
            None => {}
        }
    }

    /// Abre um arquivo, substituindo o documento apenas se a leitura funcionar.
    fn open_document(&mut self, path: &Path) -> Result<(), FileError> {
        let text = files::read_document(path)?;

        self.cancel_session();

        self.buffer = Buffer::from_text(&text);
        self.path = Some(path.to_path_buf());
        self.document_name = document_name(path);
        self.line_ending = detect_line_ending(&text).to_owned();
        self.syntax = LanguageId::from_path(path).map(|language| SyntaxState::new(language, &text));
        self.view.reset();
        self.sync_viewport();
        self.ensure_visible();
        self.set_info("arquivo aberto");

        Ok(())
    }

    /// Salva o documento no caminho informado.
    ///
    /// A sessão de edição é concluída antes da leitura do texto. O estado de
    /// salvamento só é atualizado depois que a escrita é confirmada.
    fn save_document_to(&mut self, path: &Path) -> Result<(), DocumentError> {
        self.commit_session();

        let text = self.buffer.text()?;
        files::write_document(path, &text)?;
        self.buffer.mark_saved()?;

        self.set_syntax_for_path(path, &text);
        self.path = Some(path.to_path_buf());
        self.document_name = document_name(path);
        self.set_info("arquivo salvo");

        Ok(())
    }

    fn save(&mut self) {
        let Some(path) = self.path().map(Path::to_path_buf) else {
            self.open_prompt(PromptKind::SaveAs);
            return;
        };

        if let Err(error) = self.save_document_to(&path) {
            self.set_error(error.to_string());
        }
    }

    /// Solicita o encerramento, preservando alterações não salvas.
    fn request_quit(&mut self) {
        if self.confirm.is_some() {
            return;
        }

        // Um prompt aberto é cancelado antes de avaliar a saída para não deixar
        // uma operação de arquivo pendente nem duplicar confirmações.
        if self.prompt.is_some() {
            self.prompt = None;
            self.pending_after_save = None;
            self.mode = Mode::Editor;
        }

        self.commit_session();

        if self.buffer.is_consistent() && !self.buffer.is_modified() {
            self.running = false;
            return;
        }

        self.open_confirm(PendingAction::Quit);
    }

    fn open_confirm(&mut self, pending: PendingAction) {
        if self.confirm.is_some() {
            return;
        }

        let save_available = self.buffer.is_consistent();
        let selected = if save_available {
            ConfirmChoice::Save
        } else {
            ConfirmChoice::Cancel
        };

        self.confirm = Some(ConfirmDialog {
            pending,
            selected,
            save_available,
            error: None,
        });
        self.mode = Mode::Confirm;
        self.needs_redraw = true;
    }

    fn apply_confirm_action(&mut self, action: ConfirmAction) {
        match action {
            ConfirmAction::MoveLeft => self.move_confirm_selection(false),
            ConfirmAction::MoveRight => self.move_confirm_selection(true),
            ConfirmAction::Save => self.resolve_confirm(ConfirmChoice::Save),
            ConfirmAction::Discard => self.resolve_confirm(ConfirmChoice::Discard),
            ConfirmAction::Cancel => self.cancel_confirm(),
            ConfirmAction::Activate => {
                if let Some(dialog) = self.confirm.as_ref() {
                    self.resolve_confirm(dialog.selected());
                }
            }
        }
    }

    fn move_confirm_selection(&mut self, forward: bool) {
        let Some(dialog) = self.confirm.as_mut() else {
            return;
        };

        dialog.error = None;
        let selected = dialog.selected;
        dialog.selected = if forward {
            selected.next(dialog.save_available)
        } else {
            selected.previous(dialog.save_available)
        };
        self.needs_redraw = true;
    }

    fn resolve_confirm(&mut self, choice: ConfirmChoice) {
        if choice == ConfirmChoice::Cancel {
            self.cancel_confirm();
            return;
        }

        let Some(dialog) = self.confirm.as_ref() else {
            return;
        };

        if choice == ConfirmChoice::Save && !dialog.save_available() {
            self.set_confirm_error(
                "documento em recuperação pendente; salvar indisponível".to_owned(),
            );
            return;
        }

        let pending = dialog.pending.clone();

        match choice {
            ConfirmChoice::Save => self.save_for_pending(pending),
            ConfirmChoice::Discard => self.complete_pending(pending),
            ConfirmChoice::Cancel => {}
        }
    }

    fn save_for_pending(&mut self, pending: PendingAction) {
        match self.path().map(Path::to_path_buf) {
            Some(path) => match self.save_document_to(&path) {
                Ok(()) => self.complete_pending(pending),
                Err(error) => self.set_confirm_error(error.to_string()),
            },
            None => {
                self.pending_after_save = Some(pending);
                self.confirm = None;
                self.open_prompt(PromptKind::SaveAs);
            }
        }
    }

    fn complete_pending(&mut self, pending: PendingAction) {
        self.confirm = None;
        self.pending_after_save = None;
        self.mode = Mode::Editor;

        match pending {
            PendingAction::Quit => self.running = false,
            PendingAction::Open(path) => {
                if let Err(error) = self.open_document(&path) {
                    self.set_error(error.to_string());
                }
            }
        }

        self.needs_redraw = true;
    }

    fn cancel_confirm(&mut self) {
        let kind = self.confirm.as_ref().map(ConfirmDialog::kind);
        self.confirm = None;
        self.pending_after_save = None;
        self.mode = Mode::Editor;
        self.needs_redraw = true;

        match kind {
            Some(ConfirmKind::Quit) => self.set_info("saída cancelada"),
            Some(ConfirmKind::Open) => self.set_info("abertura cancelada"),
            None => {}
        }
    }

    fn set_confirm_error(&mut self, text: String) {
        if let Some(dialog) = self.confirm.as_mut() {
            dialog.error = Some(text.clone());
        }
        self.set_error(text);
    }

    fn set_info(&mut self, text: impl Into<String>) {
        self.status = Some(StatusMessage {
            kind: MessageKind::Info,
            text: text.into(),
        });
        self.needs_redraw = true;
    }

    fn set_error(&mut self, text: impl Into<String>) {
        self.status = Some(StatusMessage {
            kind: MessageKind::Error,
            text: text.into(),
        });
        self.needs_redraw = true;
    }

    fn report_buffer_error(&mut self, context: &str, error: &BufferError) {
        self.set_error(format!("{context}: {error}"));
    }

    fn report_recovery(&mut self) {
        self.set_error("o documento está em recuperação pendente; edição indisponível");
    }

    /// Coloca o documento em recuperação pendente para testes de segurança.
    #[cfg(test)]
    pub fn force_recovery_for_tests(&mut self) {
        self.commit_session();
        self.buffer.force_recovery_pending_for_tests();
        self.needs_redraw = true;
    }

    /// Define uma mensagem de status para testes de renderização.
    #[cfg(test)]
    pub fn set_info_for_tests(&mut self, text: &str) {
        self.set_info(text);
    }
}

/// Calcula o início da janela horizontal do prompt.
///
/// O cursor permanece visível. Quando está no fim do texto, a janela mostra o
/// máximo possível do sufixo; quando está no meio, o cursor é centralizado.
fn prompt_visible_start(input: &str, cursor: usize, width: usize) -> usize {
    let characters: Vec<char> = input.chars().collect();
    let cursor = cursor.min(characters.len());

    if width == 0 || characters.is_empty() {
        return cursor;
    }

    let mut columns = Vec::with_capacity(characters.len() + 1);
    let mut column = 0usize;
    columns.push(0);
    for &character in &characters {
        column += char_width(character, column);
        columns.push(column);
    }

    let cursor_column = columns[cursor];
    let cursor_width = if cursor < characters.len() {
        (columns[cursor + 1] - columns[cursor]).max(1)
    } else {
        1
    };

    if cursor_column + cursor_width <= width {
        return 0;
    }

    if cursor == characters.len() {
        let mut start = cursor;
        while start > 0 {
            let candidate = start - 1;
            if cursor_column - columns[candidate] + cursor_width > width {
                break;
            }
            start = candidate;
        }
        return start;
    }

    let target_left = cursor_column.saturating_sub(width / 2);
    let mut start = 0;
    while start < cursor && columns[start + 1] <= target_left {
        start += 1;
    }

    while start < cursor && cursor_column - columns[start] + cursor_width > width {
        start += 1;
    }

    start
}

impl Drop for App {
    fn drop(&mut self) {
        // O `Drop` não pode reportar erros. Em encerramento normal a sessão já
        // foi concluída; esta é apenas uma rede de segurança para panics.
        if self.buffer.has_active_transaction() {
            let _ = self.buffer.cancel_transaction();
        }
    }
}

fn detect_line_ending(text: &str) -> &'static str {
    match text.find('\n') {
        Some(index) if index > 0 && text.as_bytes()[index - 1] == b'\r' => "\r\n",
        _ => "\n",
    }
}

fn document_name(path: &Path) -> String {
    path.file_name()
        .map(|name| name.to_string_lossy().into_owned())
        .filter(|name| !name.is_empty())
        .unwrap_or_else(|| path.to_string_lossy().into_owned())
}

#[cfg(test)]
mod tests {
    use std::fs;
    use std::sync::atomic::{AtomicU64, Ordering};

    use nexus_syntax::TokenKind;
    use ratatui::crossterm::event::{KeyCode, KeyEvent, KeyEventKind, KeyModifiers};

    use super::*;

    static TEST_COUNTER: AtomicU64 = AtomicU64::new(0);

    struct TempDir {
        path: PathBuf,
    }

    impl TempDir {
        fn new(label: &str) -> Self {
            let counter = TEST_COUNTER.fetch_add(1, Ordering::Relaxed);
            let path = std::env::temp_dir().join(format!(
                "nexus-tui-app-{}-{}-{label}",
                std::process::id(),
                counter
            ));
            fs::create_dir_all(&path).expect("criar diretório temporário");
            Self { path }
        }

        fn join(&self, name: &str) -> PathBuf {
            self.path.join(name)
        }
    }

    impl Drop for TempDir {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.path);
        }
    }

    fn app(text: &str) -> App {
        let mut app = App::with_text(80, 24, text);
        app.mark_rendered();
        app
    }

    fn key(code: KeyCode) -> KeyEvent {
        KeyEvent::new(code, KeyModifiers::NONE)
    }

    fn ctrl(code: KeyCode) -> KeyEvent {
        KeyEvent::new(code, KeyModifiers::CONTROL)
    }

    fn shift(code: KeyCode) -> KeyEvent {
        KeyEvent::new(code, KeyModifiers::SHIFT)
    }

    fn press(app: &mut App, code: KeyCode) {
        app.update(Event::Key(key(code)));
    }

    fn press_ctrl(app: &mut App, code: KeyCode) {
        app.update(Event::Key(ctrl(code)));
    }

    fn press_shift(app: &mut App, code: KeyCode) {
        app.update(Event::Key(shift(code)));
    }

    fn text(app: &App) -> String {
        app.buffer().text().unwrap()
    }

    fn has_token(app: &App, kind: TokenKind, needle: &str) -> bool {
        let Some(syntax) = app.syntax() else {
            return false;
        };
        let source = syntax.text();

        syntax.highlights().iter().any(|span| {
            if span.kind != kind {
                return false;
            }

            let start = source
                .char_indices()
                .nth(span.range.start.0)
                .map(|(byte, _)| byte)
                .unwrap_or(source.len());
            let end = source
                .char_indices()
                .nth(span.range.end.0)
                .map(|(byte, _)| byte)
                .unwrap_or(source.len());

            source[start..end].contains(needle)
        })
    }

    #[test]
    fn new_app_starts_empty_and_running() {
        let app = App::new(80, 24);

        assert!(app.is_running());
        assert_eq!(text(&app), "");
        assert_eq!(app.view().cursor(), CharOffset(0));
        assert!(!app.buffer().is_modified());
        assert_eq!(app.mode(), Mode::Editor);
    }

    #[test]
    fn ctrl_c_requests_quit() {
        let mut app = App::new(80, 24);

        app.update(Event::Key(KeyEvent::new(
            KeyCode::Char('c'),
            KeyModifiers::CONTROL,
        )));

        assert!(!app.is_running());
    }

    #[test]
    fn unrelated_keys_do_not_change_state() {
        let mut app = App::new(80, 24);
        app.mark_rendered();

        app.update(Event::Key(KeyEvent::new(
            KeyCode::F(12),
            KeyModifiers::NONE,
        )));
        app.update(Event::Key(KeyEvent::new_with_kind(
            KeyCode::Char('c'),
            KeyModifiers::CONTROL,
            KeyEventKind::Release,
        )));

        assert!(app.is_running());
        assert!(!app.needs_redraw());
    }

    #[test]
    fn resize_updates_viewport_and_requests_redraw() {
        let mut app = App::new(80, 24);
        app.mark_rendered();

        app.update(Event::Resize {
            width: 120,
            height: 40,
        });

        assert_eq!(app.terminal_size(), (120, 40));
        assert!(app.needs_redraw());
    }

    #[test]
    fn typing_is_grouped_into_one_transaction() {
        let mut app = app("");

        press(&mut app, KeyCode::Char('a'));
        press(&mut app, KeyCode::Char('b'));
        press(&mut app, KeyCode::Char('c'));

        assert_eq!(text(&app), "abc");
        assert_eq!(app.view().cursor(), CharOffset(3));
        assert!(app.buffer().has_active_transaction());

        app.on_idle();

        assert!(!app.buffer().has_active_transaction());
        assert_eq!(app.buffer().revision(), 1);
        assert!(app.buffer().can_undo());

        press_ctrl(&mut app, KeyCode::Char('z'));

        assert_eq!(text(&app), "");
        assert_eq!(app.view().cursor(), CharOffset(0));
    }

    #[test]
    fn movement_commits_the_typing_session() {
        let mut app = app("");

        press(&mut app, KeyCode::Char('a'));
        press(&mut app, KeyCode::Char('b'));
        press(&mut app, KeyCode::Left);

        assert!(!app.buffer().has_active_transaction());
        assert_eq!(app.view().cursor(), CharOffset(1));
        assert_eq!(text(&app), "ab");

        press_ctrl(&mut app, KeyCode::Char('z'));

        assert_eq!(text(&app), "");
    }

    #[test]
    fn changing_operation_starts_a_new_session() {
        let mut app = app("");

        press(&mut app, KeyCode::Char('a'));
        press(&mut app, KeyCode::Char('b'));
        press(&mut app, KeyCode::Backspace);
        app.on_idle();

        assert_eq!(text(&app), "a");

        press_ctrl(&mut app, KeyCode::Char('z'));
        assert_eq!(text(&app), "ab");

        press_ctrl(&mut app, KeyCode::Char('z'));
        assert_eq!(text(&app), "");
    }

    #[test]
    fn inserts_spaces_tabs_and_newlines() {
        let mut app = app("");

        press(&mut app, KeyCode::Char(' '));
        press(&mut app, KeyCode::Tab);
        press(&mut app, KeyCode::Enter);
        press(&mut app, KeyCode::Char('x'));

        assert_eq!(text(&app), " \t\nx");
        assert_eq!(app.view().cursor(), CharOffset(4));
    }

    #[test]
    fn backspace_at_line_start_joins_lines() {
        let mut app = app("ab\ncd");
        app.view.set_cursor(&app.buffer, CharOffset(3)).unwrap();

        press(&mut app, KeyCode::Backspace);

        assert_eq!(text(&app), "abcd");
        assert_eq!(app.view().cursor(), CharOffset(2));

        press_ctrl(&mut app, KeyCode::Char('z'));
        assert_eq!(text(&app), "ab\ncd");
    }

    #[test]
    fn delete_at_line_end_joins_lines() {
        let mut app = app("ab\ncd");
        app.view.set_cursor(&app.buffer, CharOffset(2)).unwrap();

        press(&mut app, KeyCode::Delete);

        assert_eq!(text(&app), "abcd");
        assert_eq!(app.view().cursor(), CharOffset(2));

        press_ctrl(&mut app, KeyCode::Char('z'));
        assert_eq!(text(&app), "ab\ncd");
    }

    #[test]
    fn backspace_removes_previous_character() {
        let mut app = app("café");
        app.view.set_cursor(&app.buffer, CharOffset(4)).unwrap();

        press(&mut app, KeyCode::Backspace);

        assert_eq!(text(&app), "caf");
        assert_eq!(app.view().cursor(), CharOffset(3));
    }

    #[test]
    fn delete_removes_next_character() {
        let mut app = app("café");
        app.view.set_cursor(&app.buffer, CharOffset(3)).unwrap();

        press(&mut app, KeyCode::Delete);

        assert_eq!(text(&app), "caf");
        assert_eq!(app.view().cursor(), CharOffset(3));
    }

    #[test]
    fn selection_can_be_deleted() {
        let mut app = app("abcdef");
        app.view
            .set_selection(&app.buffer, CharOffset(1), CharOffset(4))
            .unwrap();

        press(&mut app, KeyCode::Delete);

        assert_eq!(text(&app), "aef");
        assert_eq!(app.view().cursor(), CharOffset(1));
        assert!(!app.view().has_selection());

        press_ctrl(&mut app, KeyCode::Char('z'));
        assert_eq!(text(&app), "abcdef");
    }

    #[test]
    fn selection_can_be_replaced_by_typing() {
        let mut app = app("abcdef");
        app.view
            .set_selection(&app.buffer, CharOffset(1), CharOffset(4))
            .unwrap();

        press(&mut app, KeyCode::Char('X'));

        assert_eq!(text(&app), "aXef");
        assert_eq!(app.view().cursor(), CharOffset(2));

        press_ctrl(&mut app, KeyCode::Char('z'));
        assert_eq!(text(&app), "abcdef");

        press_ctrl(&mut app, KeyCode::Char('y'));
        assert_eq!(text(&app), "aXef");
    }

    #[test]
    fn select_all_then_replace_entire_document() {
        let mut app = app("café\n界");

        press_ctrl(&mut app, KeyCode::Char('a'));
        press(&mut app, KeyCode::Char('x'));

        assert_eq!(text(&app), "x");
        assert_eq!(app.view().cursor(), CharOffset(1));

        press_ctrl(&mut app, KeyCode::Char('z'));
        assert_eq!(text(&app), "café\n界");
    }

    #[test]
    fn escape_cancels_selection_without_touching_buffer() {
        let mut app = app("abc");

        press_shift(&mut app, KeyCode::Right);
        press_shift(&mut app, KeyCode::Right);
        assert!(app.view().has_selection());

        press(&mut app, KeyCode::Esc);

        assert!(!app.view().has_selection());
        assert_eq!(text(&app), "abc");
    }

    #[test]
    fn undo_and_redo_keep_cursor_valid() {
        let mut app = app("");

        press(&mut app, KeyCode::Char('a'));
        press(&mut app, KeyCode::Char('b'));
        press(&mut app, KeyCode::Char('c'));
        app.on_idle();

        press_ctrl(&mut app, KeyCode::Char('z'));
        assert_eq!(text(&app), "");
        assert_eq!(app.view().cursor(), CharOffset(0));

        press_ctrl(&mut app, KeyCode::Char('y'));
        assert_eq!(text(&app), "abc");
        assert!(app.view().cursor().0 <= app.buffer().len_chars().unwrap());
        assert_eq!(app.view().cursor_line(app.buffer()).unwrap(), 0);
    }

    #[test]
    fn new_edit_after_undo_invalidates_redo() {
        let mut app = app("");

        press(&mut app, KeyCode::Char('a'));
        app.on_idle();
        press_ctrl(&mut app, KeyCode::Char('z'));
        assert!(app.buffer().can_redo());

        press(&mut app, KeyCode::Char('b'));
        app.on_idle();

        assert!(!app.buffer().can_redo());
        assert_eq!(text(&app), "b");
    }

    #[test]
    fn cancel_session_reverts_uncommitted_edits() {
        let mut app = app("abc");
        app.view.set_cursor(&app.buffer, CharOffset(3)).unwrap();

        press(&mut app, KeyCode::Char('d'));
        assert_eq!(text(&app), "abcd");
        assert!(app.buffer().has_active_transaction());

        app.cancel_session();

        assert_eq!(text(&app), "abc");
        assert!(!app.buffer().has_active_transaction());
        assert_eq!(app.buffer().revision(), 0);
        assert!(!app.buffer().is_modified());
    }

    #[test]
    fn open_document_replaces_current_document() {
        let directory = TempDir::new("open-valid");
        let path = directory.join("example.txt");
        fs::write(&path, "conteúdo\n").unwrap();
        let mut app = app("antigo");

        app.open_document(&path).unwrap();

        assert_eq!(text(&app), "conteúdo\n");
        assert_eq!(app.path(), Some(path.as_path()));
        assert_eq!(app.document_name(), "example.txt");
        assert_eq!(app.view().cursor(), CharOffset(0));
        assert!(!app.buffer().is_modified());
    }

    #[test]
    fn open_empty_document() {
        let directory = TempDir::new("open-empty");
        let path = directory.join("empty.txt");
        fs::write(&path, "").unwrap();
        let mut app = app("antigo");

        app.open_document(&path).unwrap();

        assert_eq!(text(&app), "");
        assert_eq!(app.buffer().line_count().unwrap(), 1);
    }

    #[test]
    fn failed_open_keeps_current_document() {
        let directory = TempDir::new("open-missing");
        let path = directory.join("missing.txt");
        let mut app = app("antigo");

        let result = app.open_document(&path);

        assert!(result.is_err());
        assert_eq!(text(&app), "antigo");
        assert_eq!(app.path(), None);
        assert_eq!(app.document_name(), "sem título");
    }

    #[test]
    fn invalid_utf8_open_keeps_current_document() {
        let directory = TempDir::new("open-invalid-utf8");
        let path = directory.join("invalid.bin");
        fs::write(&path, [0xFF, 0xFE]).unwrap();
        let mut app = app("antigo");

        let result = app.open_document(&path);

        assert!(result.is_err());
        assert_eq!(text(&app), "antigo");
    }

    #[test]
    fn save_preserves_line_endings_and_marks_document_saved() {
        let directory = TempDir::new("save");
        let path = directory.join("document.txt");
        let mut app = app("linha 1\r\nlinha 2\r\n");

        app.save_document_to(&path).unwrap();

        assert_eq!(fs::read(&path).unwrap(), b"linha 1\r\nlinha 2\r\n");
        assert!(!app.buffer().is_modified());
        assert_eq!(app.path(), Some(path.as_path()));
        assert_eq!(app.document_name(), "document.txt");
        assert_eq!(app.line_ending, "\r\n");
    }

    #[test]
    fn editing_after_save_marks_document_modified_again() {
        let directory = TempDir::new("save-then-edit");
        let path = directory.join("document.txt");
        let mut app = app("abc");

        app.save_document_to(&path).unwrap();
        assert!(!app.buffer().is_modified());

        app.view.set_cursor(&app.buffer, CharOffset(3)).unwrap();
        press(&mut app, KeyCode::Char('d'));
        app.on_idle();

        assert!(app.buffer().is_modified());

        app.save_document_to(&path).unwrap();
        assert_eq!(fs::read(&path).unwrap(), b"abcd");
        assert!(!app.buffer().is_modified());
    }

    #[test]
    fn save_failure_keeps_document_modified() {
        let directory = TempDir::new("save-failure");
        let path = directory.join("missing").join("document.txt");
        let mut app = app("abc");

        press(&mut app, KeyCode::Char('d'));
        app.on_idle();
        assert!(app.buffer().is_modified());

        let result = app.save_document_to(&path);

        assert!(result.is_err());
        assert!(app.buffer().is_modified());
        assert_eq!(app.path(), None);
        assert!(!path.exists());
    }

    #[test]
    fn save_as_switches_language_and_creates_syntax_state() {
        let directory = TempDir::new("save-as-language");
        let path = directory.join("programa.rs");
        let mut app = app("fn main() {}");

        assert!(app.syntax().is_none());
        assert_eq!(app.language_name(), "Texto");

        app.save_document_to(&path).unwrap();

        assert!(app.syntax().is_some());
        assert_eq!(app.language_name(), "Rust");
        assert_eq!(app.syntax().unwrap().text(), text(&app));
        assert!(has_token(&app, TokenKind::Keyword, "fn"));
    }

    #[test]
    fn save_as_with_same_language_preserves_syntax_tree() {
        let directory = TempDir::new("save-as-same-language");
        let path = directory.join("outro.rs");
        let mut app = App::with_document(80, 24, Path::new("main.rs"), "fn main() {}");
        let before = app.syntax().unwrap().update_count();

        app.save_document_to(&path).unwrap();

        assert_eq!(app.syntax().unwrap().update_count(), before);
    }

    #[test]
    fn typing_and_undo_redo_keep_syntax_in_sync() {
        let mut app = App::with_document(80, 24, Path::new("main.rs"), "fn main() {}");
        app.mark_rendered();
        app.view.set_cursor(&app.buffer, CharOffset(12)).unwrap();

        press(&mut app, KeyCode::Enter);
        for character in "// nota".chars() {
            press(&mut app, KeyCode::Char(character));
        }
        app.on_idle();

        assert_eq!(app.syntax().unwrap().text(), text(&app));
        assert!(has_token(&app, TokenKind::Comment, "nota"));

        press_ctrl(&mut app, KeyCode::Char('z'));
        assert_eq!(app.syntax().unwrap().text(), text(&app));
        assert!(!has_token(&app, TokenKind::Comment, "nota"));

        press_ctrl(&mut app, KeyCode::Char('y'));
        assert_eq!(app.syntax().unwrap().text(), text(&app));
        assert!(has_token(&app, TokenKind::Comment, "nota"));
    }

    #[test]
    fn deleting_text_updates_syntax_state() {
        let mut app = App::with_document(
            80,
            24,
            Path::new("main.rs"),
            "fn main() { let valor = 42; }",
        );
        app.view.set_cursor(&app.buffer, CharOffset(26)).unwrap();
        app.mark_rendered();

        assert!(has_token(&app, TokenKind::Number, "42"));

        press(&mut app, KeyCode::Backspace);
        press(&mut app, KeyCode::Backspace);
        app.on_idle();

        assert_eq!(app.syntax().unwrap().text(), text(&app));
        assert!(!has_token(&app, TokenKind::Number, "42"));
    }

    #[test]
    fn newline_insertion_uses_detected_line_ending() {
        let mut app = app("a\r\nb");
        app.view.set_cursor(&app.buffer, CharOffset(3)).unwrap();

        press(&mut app, KeyCode::Enter);

        assert_eq!(text(&app), "a\r\n\r\nb");
        assert_eq!(app.line_ending, "\r\n");
    }

    #[test]
    fn open_detects_crlf_line_ending() {
        let directory = TempDir::new("open-crlf");
        let path = directory.join("document.txt");
        fs::write(&path, "a\r\nb").unwrap();
        let mut app = app("");

        app.open_document(&path).unwrap();
        assert_eq!(app.line_ending, "\r\n");

        app.view.set_cursor(&app.buffer, CharOffset(1)).unwrap();
        press(&mut app, KeyCode::Enter);

        assert_eq!(text(&app), "a\r\n\r\nb");
    }

    #[test]
    fn ctrl_s_without_path_opens_save_as_prompt() {
        let mut app = app("");

        press_ctrl(&mut app, KeyCode::Char('s'));

        assert_eq!(app.mode(), Mode::Prompt(PromptKind::SaveAs));
        assert!(app.prompt().is_some());
    }

    #[test]
    fn prompt_save_as_writes_file_and_marks_saved() {
        let directory = TempDir::new("prompt-save");
        let path = directory.join("new.txt");
        let mut app = app("");

        press(&mut app, KeyCode::Char('h'));
        press(&mut app, KeyCode::Char('i'));
        app.on_idle();

        press_ctrl(&mut app, KeyCode::Char('s'));
        for character in path.to_string_lossy().chars() {
            app.apply_action(Action::PromptChar(character));
        }
        app.apply_action(Action::PromptConfirm);

        assert_eq!(app.mode(), Mode::Editor);
        assert!(app.prompt().is_none());
        assert_eq!(fs::read(&path).unwrap(), b"hi");
        assert_eq!(app.path(), Some(path.as_path()));
        assert_eq!(app.document_name(), "new.txt");
        assert!(!app.buffer().is_modified());
    }

    #[test]
    fn ctrl_s_with_associated_path_saves_directly() {
        let directory = TempDir::new("ctrl-s");
        let path = directory.join("document.txt");
        let mut app = app("abc");

        app.save_document_to(&path).unwrap();
        app.view.set_cursor(&app.buffer, CharOffset(3)).unwrap();
        press(&mut app, KeyCode::Char('d'));
        app.on_idle();

        press_ctrl(&mut app, KeyCode::Char('s'));

        assert_eq!(fs::read(&path).unwrap(), b"abcd");
        assert!(!app.buffer().is_modified());
        assert_eq!(app.mode(), Mode::Editor);
    }

    #[test]
    fn prompt_edits_and_confirms_open() {
        let directory = TempDir::new("prompt-open");
        let path = directory.join("document.txt");
        fs::write(&path, "texto").unwrap();
        let mut app = app("antigo");

        press_ctrl(&mut app, KeyCode::Char('o'));
        for character in path.to_string_lossy().chars() {
            app.apply_action(Action::PromptChar(character));
        }
        app.apply_action(Action::PromptConfirm);

        assert_eq!(app.mode(), Mode::Editor);
        assert!(app.prompt().is_none());
        assert_eq!(text(&app), "texto");
    }

    #[test]
    fn prompt_cancel_keeps_document() {
        let mut app = app("antigo");

        press_ctrl(&mut app, KeyCode::Char('o'));
        app.apply_action(Action::PromptChar('x'));
        app.apply_action(Action::PromptCancel);

        assert_eq!(app.mode(), Mode::Editor);
        assert!(app.prompt().is_none());
        assert_eq!(text(&app), "antigo");
    }

    #[test]
    fn prompt_open_failure_keeps_prompt_and_document() {
        let directory = TempDir::new("prompt-open-failure");
        let path = directory.join("missing.txt");
        let mut app = app("antigo");

        press_ctrl(&mut app, KeyCode::Char('o'));
        for character in path.to_string_lossy().chars() {
            app.apply_action(Action::PromptChar(character));
        }
        app.apply_action(Action::PromptConfirm);

        assert_eq!(app.mode(), Mode::Prompt(PromptKind::Open));
        assert_eq!(
            app.prompt().map(Prompt::input),
            Some(path.to_string_lossy().as_ref())
        );
        assert_eq!(text(&app), "antigo");
        assert_eq!(
            app.status_message().map(|message| message.kind),
            Some(MessageKind::Error)
        );
    }

    #[test]
    fn prompt_supports_cursor_editing() {
        let mut app = app("");

        press_ctrl(&mut app, KeyCode::Char('o'));
        app.apply_action(Action::PromptChar('a'));
        app.apply_action(Action::PromptChar('b'));
        app.apply_action(Action::PromptChar('c'));
        app.apply_action(Action::PromptLeft);
        app.apply_action(Action::PromptBackspace);
        app.apply_action(Action::PromptEnd);
        app.apply_action(Action::PromptChar('d'));

        assert_eq!(app.prompt().map(Prompt::input), Some("acd"));
    }

    #[test]
    fn help_mode_opens_and_closes() {
        let mut app = app("");

        press_ctrl(&mut app, KeyCode::Char('h'));
        assert_eq!(app.mode(), Mode::Help);

        press(&mut app, KeyCode::Esc);
        assert_eq!(app.mode(), Mode::Editor);
    }

    fn modified_app(text: &str) -> App {
        let mut application = app(text);
        let len = application.buffer().len_chars().unwrap();
        application
            .view
            .set_cursor(&application.buffer, CharOffset(len))
            .unwrap();
        press(&mut application, KeyCode::Char('x'));
        application.on_idle();
        application
    }

    fn type_prompt(app: &mut App, text: &str) {
        for character in text.chars() {
            app.apply_action(Action::PromptChar(character));
        }
    }

    // ----- Saída -----

    #[test]
    fn quit_unmodified_does_not_show_confirmation() {
        let mut application = app("abc");

        press_ctrl(&mut application, KeyCode::Char('q'));

        assert!(!application.is_running());
        assert!(application.confirm().is_none());
    }

    #[test]
    fn quit_modified_opens_confirmation() {
        let mut application = modified_app("");

        press_ctrl(&mut application, KeyCode::Char('q'));

        assert!(application.is_running());
        assert_eq!(application.mode(), Mode::Confirm);
        let dialog = application.confirm().unwrap();
        assert_eq!(dialog.kind(), ConfirmKind::Quit);
        assert_eq!(dialog.selected(), ConfirmChoice::Save);
        assert!(dialog.save_available());
    }

    #[test]
    fn quit_save_writes_and_exits() {
        let directory = TempDir::new("quit-save");
        let path = directory.join("document.txt");
        let mut application = modified_app("abc");
        application.path = Some(path.clone());

        press_ctrl(&mut application, KeyCode::Char('q'));
        press(&mut application, KeyCode::Char('s'));

        assert!(!application.is_running());
        assert_eq!(fs::read(&path).unwrap(), b"abcx");
    }

    #[test]
    fn quit_save_without_path_uses_save_as_and_exits() {
        let directory = TempDir::new("quit-save-as");
        let path = directory.join("document.txt");
        let mut application = modified_app("abc");

        press_ctrl(&mut application, KeyCode::Char('q'));
        press(&mut application, KeyCode::Char('s'));

        assert_eq!(application.mode(), Mode::Prompt(PromptKind::SaveAs));
        type_prompt(&mut application, &path.to_string_lossy());
        application.apply_action(Action::PromptConfirm);

        assert!(!application.is_running());
        assert_eq!(fs::read(&path).unwrap(), b"abcx");
    }

    #[test]
    fn quit_discard_exits_without_saving() {
        let directory = TempDir::new("quit-discard");
        let path = directory.join("document.txt");
        let mut application = app("abc");
        application.save_document_to(&path).unwrap();

        let len = application.buffer().len_chars().unwrap();
        application
            .view
            .set_cursor(&application.buffer, CharOffset(len))
            .unwrap();
        press(&mut application, KeyCode::Char('d'));
        application.on_idle();

        press_ctrl(&mut application, KeyCode::Char('q'));
        press(&mut application, KeyCode::Char('d'));

        assert!(!application.is_running());
        assert_eq!(fs::read(&path).unwrap(), b"abc");
    }

    #[test]
    fn quit_cancel_keeps_document_and_running() {
        let mut application = modified_app("abc");
        let before = text(&application);

        press_ctrl(&mut application, KeyCode::Char('q'));
        press(&mut application, KeyCode::Esc);

        assert!(application.is_running());
        assert_eq!(application.mode(), Mode::Editor);
        assert_eq!(text(&application), before);
        assert!(application.buffer().is_modified());
    }

    #[test]
    fn quit_save_failure_keeps_running_and_allows_retry() {
        let directory = TempDir::new("quit-save-retry");
        let bad_path = directory.join("missing").join("document.txt");
        let good_path = directory.join("document.txt");
        let mut application = modified_app("abc");
        application.path = Some(bad_path);

        press_ctrl(&mut application, KeyCode::Char('q'));
        press(&mut application, KeyCode::Char('s'));

        assert!(application.is_running());
        assert_eq!(application.mode(), Mode::Confirm);
        assert!(application.confirm().unwrap().error().is_some());
        assert!(application.buffer().is_modified());
        assert!(!good_path.exists());

        application.path = Some(good_path.clone());
        press(&mut application, KeyCode::Char('s'));

        assert!(!application.is_running());
        assert_eq!(fs::read(&good_path).unwrap(), b"abcx");
    }

    #[test]
    fn quit_recovery_requires_explicit_discard() {
        let mut application = app("abc");
        application.force_recovery_for_tests();

        press_ctrl(&mut application, KeyCode::Char('q'));

        assert!(application.is_running());
        let dialog = application.confirm().unwrap();
        assert_eq!(dialog.kind(), ConfirmKind::Quit);
        assert!(!dialog.save_available());
        assert_eq!(dialog.selected(), ConfirmChoice::Cancel);

        press(&mut application, KeyCode::Char('s'));
        assert!(application.is_running());
        assert!(application.confirm().unwrap().error().is_some());

        press(&mut application, KeyCode::Char('d'));
        assert!(!application.is_running());
    }

    #[test]
    fn quit_with_active_session_commits_before_confirming() {
        let mut application = app("");

        press(&mut application, KeyCode::Char('a'));
        assert!(application.buffer().has_active_transaction());

        press_ctrl(&mut application, KeyCode::Char('q'));

        assert!(!application.buffer().has_active_transaction());
        assert!(application.buffer().can_undo());
        assert_eq!(application.buffer().revision(), 1);
        assert_eq!(application.mode(), Mode::Confirm);
    }

    // ----- Abertura -----

    #[test]
    fn open_with_modified_document_prompts_before_opening() {
        let directory = TempDir::new("open-modified");
        let target = directory.join("target.txt");
        fs::write(&target, "novo").unwrap();
        let mut application = modified_app("antigo");

        press_ctrl(&mut application, KeyCode::Char('o'));
        assert_eq!(application.mode(), Mode::Prompt(PromptKind::Open));
        type_prompt(&mut application, &target.to_string_lossy());
        application.apply_action(Action::PromptConfirm);

        assert_eq!(application.mode(), Mode::Confirm);
        let dialog = application.confirm().unwrap();
        assert_eq!(dialog.kind(), ConfirmKind::Open);
        assert_eq!(dialog.target(), Some(target.as_path()));
        assert_eq!(text(&application), "antigox");
    }

    #[test]
    fn open_save_and_continue() {
        let directory = TempDir::new("open-save-continue");
        let current = directory.join("current.txt");
        let target = directory.join("target.txt");
        fs::write(&target, "novo").unwrap();
        let mut application = modified_app("antigo");
        application.path = Some(current.clone());

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, &target.to_string_lossy());
        application.apply_action(Action::PromptConfirm);
        press(&mut application, KeyCode::Char('s'));

        assert_eq!(fs::read(&current).unwrap(), b"antigox");
        assert_eq!(text(&application), "novo");
        assert_eq!(application.path(), Some(target.as_path()));
        assert_eq!(application.mode(), Mode::Editor);
    }

    #[test]
    fn open_save_without_path_uses_save_as_then_opens() {
        let directory = TempDir::new("open-save-as-continue");
        let current = directory.join("current.txt");
        let target = directory.join("target.txt");
        fs::write(&target, "novo").unwrap();
        let mut application = modified_app("antigo");

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, &target.to_string_lossy());
        application.apply_action(Action::PromptConfirm);
        press(&mut application, KeyCode::Char('s'));

        assert_eq!(application.mode(), Mode::Prompt(PromptKind::SaveAs));
        type_prompt(&mut application, &current.to_string_lossy());
        application.apply_action(Action::PromptConfirm);

        assert_eq!(fs::read(&current).unwrap(), b"antigox");
        assert_eq!(text(&application), "novo");
        assert_eq!(application.path(), Some(target.as_path()));
    }

    #[test]
    fn open_discard_and_continue() {
        let directory = TempDir::new("open-discard-continue");
        let target = directory.join("target.txt");
        fs::write(&target, "novo").unwrap();
        let mut application = modified_app("antigo");

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, &target.to_string_lossy());
        application.apply_action(Action::PromptConfirm);
        press(&mut application, KeyCode::Char('d'));

        assert_eq!(text(&application), "novo");
        assert_eq!(application.path(), Some(target.as_path()));
        assert_eq!(application.mode(), Mode::Editor);
    }

    #[test]
    fn open_cancel_preserves_document_cursor_and_selection() {
        let directory = TempDir::new("open-cancel");
        let target = directory.join("target.txt");
        fs::write(&target, "novo").unwrap();
        let mut application = modified_app("antigo");
        application
            .view
            .set_selection(&application.buffer, CharOffset(1), CharOffset(3))
            .unwrap();
        let before = text(&application);
        let cursor = application.view().cursor();
        let selection = application.view().selection_range();

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, &target.to_string_lossy());
        application.apply_action(Action::PromptConfirm);
        press(&mut application, KeyCode::Esc);

        assert!(application.is_running());
        assert_eq!(application.mode(), Mode::Editor);
        assert_eq!(text(&application), before);
        assert_eq!(application.view().cursor(), cursor);
        assert_eq!(application.view().selection_range(), selection);
    }

    #[test]
    fn open_save_failure_keeps_current_document_and_allows_retry() {
        let directory = TempDir::new("open-save-retry");
        let bad_path = directory.join("missing").join("current.txt");
        let good_path = directory.join("current.txt");
        let target = directory.join("target.txt");
        fs::write(&target, "novo").unwrap();
        let mut application = modified_app("antigo");
        application.path = Some(bad_path);

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, &target.to_string_lossy());
        application.apply_action(Action::PromptConfirm);
        press(&mut application, KeyCode::Char('s'));

        assert_eq!(application.mode(), Mode::Confirm);
        assert!(application.confirm().unwrap().error().is_some());
        assert_eq!(text(&application), "antigox");

        application.path = Some(good_path.clone());
        press(&mut application, KeyCode::Char('s'));

        assert_eq!(fs::read(&good_path).unwrap(), b"antigox");
        assert_eq!(text(&application), "novo");
    }

    #[test]
    fn open_failure_after_discard_keeps_current_document() {
        let directory = TempDir::new("open-discard-failure");
        let missing = directory.join("missing.txt");
        let mut application = modified_app("antigo");

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, &missing.to_string_lossy());
        application.apply_action(Action::PromptConfirm);
        press(&mut application, KeyCode::Char('d'));

        assert_eq!(application.mode(), Mode::Editor);
        assert_eq!(text(&application), "antigox");
        assert_eq!(
            application.status_message().map(|message| message.kind),
            Some(MessageKind::Error)
        );
    }

    #[test]
    fn open_failure_after_save_keeps_saved_current_document() {
        let directory = TempDir::new("open-save-then-failure");
        let current = directory.join("current.txt");
        let missing = directory.join("missing.txt");
        let mut application = modified_app("antigo");
        application.path = Some(current.clone());

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, &missing.to_string_lossy());
        application.apply_action(Action::PromptConfirm);
        press(&mut application, KeyCode::Char('s'));

        assert_eq!(application.mode(), Mode::Editor);
        assert_eq!(text(&application), "antigox");
        assert_eq!(application.path(), Some(current.as_path()));
        assert!(!application.buffer().is_modified());
        assert_eq!(
            application.status_message().map(|message| message.kind),
            Some(MessageKind::Error)
        );
    }

    #[test]
    fn recovery_open_requires_explicit_discard() {
        let directory = TempDir::new("open-recovery");
        let target = directory.join("target.txt");
        fs::write(&target, "novo").unwrap();
        let mut application = app("abc");
        application.force_recovery_for_tests();

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, &target.to_string_lossy());
        application.apply_action(Action::PromptConfirm);

        assert_eq!(application.mode(), Mode::Confirm);
        assert!(!application.confirm().unwrap().save_available());

        press(&mut application, KeyCode::Char('d'));

        assert_eq!(text(&application), "novo");
        assert_eq!(application.path(), Some(target.as_path()));
    }

    #[test]
    fn confirmation_ignores_editor_and_command_keys() {
        let mut application = modified_app("abc");
        let before = text(&application);

        press_ctrl(&mut application, KeyCode::Char('q'));
        assert_eq!(application.mode(), Mode::Confirm);

        press(&mut application, KeyCode::Char('X'));
        press(&mut application, KeyCode::Backspace);
        press(&mut application, KeyCode::Delete);
        press_ctrl(&mut application, KeyCode::Char('z'));
        press_ctrl(&mut application, KeyCode::Char('o'));

        assert_eq!(text(&application), before);
        assert_eq!(application.mode(), Mode::Confirm);
        assert!(application.prompt().is_none());
        assert!(application.is_running());
    }

    #[test]
    fn repeated_quit_request_does_not_duplicate_confirmation() {
        let mut application = modified_app("abc");

        press_ctrl(&mut application, KeyCode::Char('q'));
        press_ctrl(&mut application, KeyCode::Char('q'));

        assert_eq!(application.mode(), Mode::Confirm);
        assert!(application.confirm().is_some());
        assert!(application.is_running());
    }

    #[test]
    fn cancel_save_as_during_pending_quit_cancels_exit() {
        let mut application = modified_app("abc");

        press_ctrl(&mut application, KeyCode::Char('q'));
        press(&mut application, KeyCode::Char('s'));
        assert_eq!(application.mode(), Mode::Prompt(PromptKind::SaveAs));

        application.apply_action(Action::PromptCancel);

        assert!(application.is_running());
        assert_eq!(application.mode(), Mode::Editor);
        assert_eq!(text(&application), "abcx");
    }

    // ----- Prompts -----

    #[test]
    fn prompt_visible_start_short_path_is_zero() {
        let prompt = Prompt::new(PromptKind::Open, "abc".to_owned());

        assert_eq!(prompt.visible_start(20), 0);
    }

    #[test]
    fn prompt_visible_start_long_path_keeps_cursor_at_end_visible() {
        let prompt = Prompt::new(PromptKind::Open, "a".repeat(100));

        let start = prompt.visible_start(10);

        assert_eq!(start, 91);
        assert!(start > 0);
    }

    #[test]
    fn prompt_visible_start_cursor_at_start_is_zero() {
        let mut prompt = Prompt::new(PromptKind::Open, "a".repeat(100));
        prompt.move_home();

        assert_eq!(prompt.visible_start(10), 0);
    }

    #[test]
    fn prompt_visible_start_accounts_for_double_width_characters() {
        let prompt = Prompt::new(PromptKind::Open, "界".repeat(10));

        let start = prompt.visible_start(10);

        assert_eq!(start, 6);
    }

    #[test]
    fn prompt_visible_start_centers_cursor_in_the_middle() {
        let mut prompt = Prompt::new(PromptKind::Open, "a".repeat(100));
        for _ in 0..50 {
            prompt.move_left();
        }

        let start = prompt.visible_start(10);

        assert_eq!(start, 45);
    }

    #[test]
    fn prompt_horizontal_navigation_keeps_cursor_valid() {
        let mut application = app("");

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, &"a".repeat(80));
        let length = application.prompt().unwrap().input().chars().count();

        application.apply_action(Action::PromptHome);
        assert_eq!(application.prompt().unwrap().cursor(), 0);
        assert_eq!(application.prompt().unwrap().visible_start(10), 0);

        application.apply_action(Action::PromptEnd);
        assert_eq!(application.prompt().unwrap().cursor(), length);
        assert!(application.prompt().unwrap().visible_start(10) > 0);

        application.apply_action(Action::PromptLeft);
        assert_eq!(application.prompt().unwrap().cursor(), length - 1);

        application.apply_action(Action::PromptRight);
        assert_eq!(application.prompt().unwrap().cursor(), length);
    }

    #[test]
    fn prompt_preserves_spaces_and_unicode() {
        let mut application = app("");
        let path = "/tmp/café com espaço/界.txt";

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, path);

        assert_eq!(application.prompt().unwrap().input(), path);
    }

    #[test]
    fn opens_file_with_unicode_and_spaces_in_path() {
        let directory = TempDir::new("unicode-path");
        let path = directory.join("café 界.txt");
        fs::write(&path, "ok").unwrap();
        let mut application = app("");

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, &path.to_string_lossy());
        application.apply_action(Action::PromptConfirm);

        assert_eq!(text(&application), "ok");
        assert_eq!(application.path(), Some(path.as_path()));
    }

    // ----- Integridade -----

    #[test]
    fn open_with_active_session_commits_before_prompt() {
        let mut application = app("");

        press(&mut application, KeyCode::Char('a'));
        assert!(application.buffer().has_active_transaction());

        press_ctrl(&mut application, KeyCode::Char('o'));

        assert!(!application.buffer().has_active_transaction());
        assert_eq!(application.buffer().revision(), 1);
        assert_eq!(application.mode(), Mode::Prompt(PromptKind::Open));
    }

    #[test]
    fn saving_without_changes_does_not_create_revision() {
        let directory = TempDir::new("save-clean");
        let path = directory.join("document.txt");
        let mut application = app("abc");
        application.save_document_to(&path).unwrap();

        let revision = application.buffer().revision();
        assert_eq!(revision, 0);
        assert!(!application.buffer().is_modified());

        application.save_document_to(&path).unwrap();

        assert_eq!(application.buffer().revision(), revision);
        assert!(!application.buffer().is_modified());
    }

    #[test]
    fn failed_save_does_not_change_saved_revision() {
        let directory = TempDir::new("save-failure-revision");
        let path = directory.join("missing").join("document.txt");
        let mut application = app("");

        press(&mut application, KeyCode::Char('a'));
        application.on_idle();
        let saved_revision = application.buffer().saved_revision();

        let result = application.save_document_to(&path);

        assert!(result.is_err());
        assert_eq!(application.buffer().saved_revision(), saved_revision);
        assert!(application.buffer().is_modified());
    }

    #[test]
    fn successful_open_reports_success_only_after_completion() {
        let directory = TempDir::new("open-success-message");
        let path = directory.join("document.txt");
        fs::write(&path, "conteúdo").unwrap();
        let mut application = app("");

        press_ctrl(&mut application, KeyCode::Char('o'));
        type_prompt(&mut application, &path.to_string_lossy());
        application.apply_action(Action::PromptConfirm);

        assert_eq!(
            application.status_message().map(|message| message.kind),
            Some(MessageKind::Info)
        );
        assert!(
            application
                .status_message()
                .unwrap()
                .text
                .contains("arquivo aberto")
        );
        assert_eq!(text(&application), "conteúdo");
    }

    #[test]
    fn successful_save_reports_success_only_after_completion() {
        let directory = TempDir::new("save-success-message");
        let path = directory.join("document.txt");
        let mut application = modified_app("abc");
        application.path = Some(path.clone());

        press_ctrl(&mut application, KeyCode::Char('s'));

        assert_eq!(
            application.status_message().map(|message| message.kind),
            Some(MessageKind::Info)
        );
        assert!(
            application
                .status_message()
                .unwrap()
                .text
                .contains("arquivo salvo")
        );
        assert_eq!(fs::read(&path).unwrap(), b"abcx");
        assert!(!application.buffer().is_modified());
    }
}
